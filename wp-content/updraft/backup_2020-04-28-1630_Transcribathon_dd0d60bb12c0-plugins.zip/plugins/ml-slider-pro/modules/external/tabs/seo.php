<div class='row'><label><?php _e("Image Title Text", "ml-slider-pro"); ?></label></div>
<div class='row'><input class='url' type='text' name='attachment[<?php echo $this->slide->ID; ?>][title]' placeholder='Title Text' value='<?php echo $title; ?>' /></div>
<div class='row'><label><?php _e("Image Alt Text", "ml-slider-pro"); ?></label></div>
<div class='row'><input class='url' type='text' name='attachment[<?php echo $this->slide->ID; ?>][alt]' placeholder='Alt Text' value='<?php echo $alt; ?>' /></div>