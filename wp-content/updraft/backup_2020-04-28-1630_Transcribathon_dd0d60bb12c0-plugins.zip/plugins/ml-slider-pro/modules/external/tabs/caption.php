<textarea name='attachment[<?php echo $this->slide->ID; ?>][post_excerpt]' placeholder='"<?php _e( "Caption", "ml-slider" ); ?>"'><?php echo $caption; ?></textarea>
